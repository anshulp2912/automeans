"""Automatic K-means clustering."""

# Authors: Anshul Patel <anshulp2912@gmail.com>

# License: MIT
name="automeans/automeans"
__version__ = "1.0.0"
